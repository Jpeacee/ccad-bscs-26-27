<?php

namespace App\Models;

use App\Models\Book;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Genre extends Model
{
    protected $fillable = [
        'genre_name',
    ];
    public function books(): BelongsToMany
    {
        return $this->belongsToMany(Book::class, 'book_genre','genre_id','book_id')->withTimestamps();
    }
}
